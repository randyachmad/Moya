# 开发

## 测试

在本地运行测试，您需要下载Moya的依赖。
运行 `carthage update --platform iOS` 然后休息一下, 直到它完成. 😴

如果您没有安装Carthage, 查看 [installation instructions](https://github.com/Carthage/Carthage#installing-carthage).
并且, 当然, 之后不要忘记运行 `carthage update --platform iOS`。

做完之后, 您可以打开 `Moya.xcodeproj` 然后点击 ⌘+U 运行测试
