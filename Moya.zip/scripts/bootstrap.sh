#!/bin/sh

scripts/carthage.sh bootstrap
cp Cartfile.resolved Carthage
